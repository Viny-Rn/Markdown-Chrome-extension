/* ── Markdown Studio — app.js ─────────────────────────────────────────── */

// ── State ───────────────────────────────────────────────────────────────
let currentMode = 'editor'; // 'editor' | 'preview' | 'split' | 'help'
let filename = 'untitled.md';

// ── DOM refs ────────────────────────────────────────────────────────────
const editor        = document.getElementById('editor');
const workspace     = document.getElementById('workspace');
const editorPane    = document.getElementById('editor-pane');
const previewPane   = document.getElementById('preview-pane');
const helpPane      = document.getElementById('help-pane');
const previewContent= document.getElementById('preview-content');
const wordCountEl   = document.getElementById('word-count');
const filenameDisplay = document.getElementById('filename-display');
const printOverlay  = document.getElementById('print-overlay');
const printFrame    = document.getElementById('print-frame');

// ── marked.js config ────────────────────────────────────────────────────
if (typeof marked !== 'undefined') {
  marked.setOptions({
    breaks: true,
    gfm: true,
  });
}

// ── Render preview ───────────────────────────────────────────────────────
function renderPreview() {
  if (typeof marked !== 'undefined') {
    previewContent.innerHTML = marked.parse(editor.value || '');
  } else {
    // Fallback: basic render if CDN unavailable
    previewContent.innerHTML = `<pre>${escapeHtml(editor.value)}</pre>`;
  }
}

function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// ── Word / char count ────────────────────────────────────────────────────
function updateWordCount() {
  const text = editor.value.trim();
  const words = text ? text.split(/\s+/).length : 0;
  wordCountEl.textContent = `${words} w`;
}

// ── Mode switching ────────────────────────────────────────────────────────
function setMode(mode) {
  currentMode = mode;
  workspace.className = 'workspace';
  editorPane.classList.add('hidden');
  previewPane.classList.add('hidden');
  helpPane.classList.add('hidden');

  document.querySelectorAll('.nav-btn[data-panel]').forEach(b => b.classList.remove('active'));

  if (mode === 'editor') {
    editorPane.classList.remove('hidden');
    document.getElementById('btn-editor').classList.add('active');
    editor.focus();
  } else if (mode === 'preview') {
    renderPreview();
    previewPane.classList.remove('hidden');
    document.getElementById('btn-preview').classList.add('active');
  } else if (mode === 'split') {
    renderPreview();
    workspace.classList.add('split');
    editorPane.classList.remove('hidden');
    previewPane.classList.remove('hidden');
    document.getElementById('btn-split').classList.add('active');
  } else if (mode === 'help') {
    helpPane.classList.remove('hidden');
    document.getElementById('btn-help').classList.add('active');
  }
}

// ── Save as .md ───────────────────────────────────────────────────────────
function saveMarkdown() {
  const blob = new Blob([editor.value], { type: 'text/markdown' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ── Export as HTML ────────────────────────────────────────────────────────
function exportHtml() {
  const html = typeof marked !== 'undefined'
    ? marked.parse(editor.value || '')
    : `<pre>${escapeHtml(editor.value)}</pre>`;

  const full = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>${filename.replace('.md', '')}</title>
  <style>
    body { font-family: 'Georgia', serif; max-width: 720px; margin: 60px auto; padding: 0 24px; font-size: 18px; line-height: 1.75; color: #1c1917; background: #faf7f2; }
    h1 { font-size: 2.2em; font-weight: 300; border-bottom: 2px solid #e0d8cc; padding-bottom: 0.3em; margin-bottom: 0.6em; }
    h2 { font-size: 1.6em; font-weight: 400; margin-top: 1.4em; }
    h3 { font-size: 1.25em; font-style: italic; }
    blockquote { border-left: 3px solid #d4824a; padding: 4px 20px; color: #9c8f7e; font-style: italic; background: #f0ebe1; }
    code { font-family: monospace; font-size: 0.85em; background: #f0ebe1; padding: 1px 6px; border-radius: 4px; }
    pre { background: #1c1917; color: #e8d5b7; padding: 20px 24px; border-radius: 8px; overflow-x: auto; }
    pre code { background: none; color: inherit; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #e0d8cc; padding: 8px 14px; }
    th { background: #f0ebe1; }
    a { color: #b5451b; }
    img { max-width: 100%; }
  </style>
</head>
<body>${html}</body>
</html>`;

  const blob = new Blob([full], { type: 'text/html' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = filename.replace('.md', '') + '.html';
  a.click();
  URL.revokeObjectURL(url);
}

// ── Print preview ─────────────────────────────────────────────────────────
function openPrintPreview() {
  const html = typeof marked !== 'undefined'
    ? marked.parse(editor.value || '')
    : `<pre>${escapeHtml(editor.value)}</pre>`;
  printFrame.innerHTML = html;
  printOverlay.classList.remove('hidden');
}

document.getElementById('print-confirm').addEventListener('click', () => {
  window.print();
});

document.getElementById('print-close').addEventListener('click', () => {
  printOverlay.classList.add('hidden');
});

// ── Help content ──────────────────────────────────────────────────────────
const HELP_DATA = [
  {
    title: 'Headings',
    rows: [
      ['# H1',        'Heading level 1'],
      ['## H2',       'Heading level 2'],
      ['### H3',      'Heading level 3'],
      ['#### H4',     'Heading level 4'],
      ['##### H5',    'Heading level 5'],
      ['###### H6',   'Heading level 6'],
    ]
  },
  {
    title: 'Emphasis',
    rows: [
      ['**bold**',          'Bold text'],
      ['*italic*',          'Italic text'],
      ['_italic_',          'Italic (alt)'],
      ['~~strikethrough~~', 'Strikethrough'],
      ['**_bold italic_**', 'Bold & italic'],
      ['`inline code`',     'Inline code'],
    ]
  },
  {
    title: 'Lists',
    rows: [
      ['- item',        'Unordered list item'],
      ['* item',        'Unordered list (alt)'],
      ['+ item',        'Unordered list (alt)'],
      ['1. item',       'Ordered list item'],
      ['  - nested',    'Nested list (2 spaces)'],
      ['- [x] task',    'Checked task item'],
      ['- [ ] task',    'Unchecked task item'],
    ]
  },
  {
    title: 'Links & Images',
    rows: [
      ['[text](url)',            'Hyperlink'],
      ['[text](url "title")',    'Link with title'],
      ['![alt](url)',            'Image'],
      ['![alt](url "title")',    'Image with title'],
      ['[ref][id] … [id]: url', 'Reference link'],
      ['<https://url>',          'Auto-link'],
    ]
  },
  {
    title: 'Blockquotes & Code',
    rows: [
      ['> quote',       'Blockquote'],
      ['>> nested',     'Nested blockquote'],
      ['```lang … ```', 'Fenced code block'],
      ['    code',      'Indented code (4 spaces)'],
    ]
  },
  {
    title: 'Tables',
    rows: [
      ['| A | B |',           'Table row'],
      ['|---|---|',            'Header separator'],
      ['|:--|--:|:-:|',       'Left / right / center align'],
    ]
  },
  {
    title: 'Horizontal Rules',
    rows: [
      ['---',   'Horizontal rule'],
      ['***',   'Horizontal rule (alt)'],
      ['___',   'Horizontal rule (alt)'],
    ]
  },
  {
    title: 'Escaping',
    rows: [
      ['\\*',   'Literal asterisk'],
      ['\\#',   'Literal hash'],
      ['\\`',   'Literal backtick'],
      ['\\[',   'Literal bracket'],
      ['&amp;', 'HTML entity: &'],
      ['&lt;',  'HTML entity: <'],
    ]
  },
  {
    title: 'Miscellaneous',
    rows: [
      ['<!-- comment -->',  'HTML comment (hidden)'],
      ['<br>',              'Line break'],
      ['&nbsp;',            'Non-breaking space'],
      ['\\',                'Trailing backslash = <br>'],
      ['---',               'Front matter delimiter (YAML)'],
    ]
  },
];

function buildHelp() {
  const container = document.getElementById('help-content');
  container.innerHTML = '';
  HELP_DATA.forEach(section => {
    const sec = document.createElement('div');
    sec.className = 'help-section';
    sec.innerHTML = `<h3>${section.title}</h3>`;
    section.rows.forEach(([syntax, desc]) => {
      const row = document.createElement('div');
      row.className = 'help-row';
      row.innerHTML = `
        <span class="help-syntax">${escapeHtml(syntax)}</span>
        <span class="help-desc">${escapeHtml(desc)}</span>
      `;
      sec.appendChild(row);
    });
    container.appendChild(sec);
  });
}

// ── Nav button wiring ─────────────────────────────────────────────────────
document.getElementById('btn-editor').addEventListener('click',       () => setMode('editor'));
document.getElementById('btn-preview').addEventListener('click',      () => setMode('preview'));
document.getElementById('btn-split').addEventListener('click',        () => setMode('split'));
document.getElementById('btn-help').addEventListener('click',         () => setMode('help'));
document.getElementById('btn-save').addEventListener('click',         saveMarkdown);
document.getElementById('btn-export-html').addEventListener('click',  exportHtml);
document.getElementById('btn-print').addEventListener('click',        openPrintPreview);

// ── Editor live sync ──────────────────────────────────────────────────────
editor.addEventListener('input', () => {
  updateWordCount();
  if (currentMode === 'preview' || currentMode === 'split') {
    renderPreview();
  }
  localStorage.setItem('md-studio-content', editor.value);
});

// ── Tab key support ───────────────────────────────────────────────────────
editor.addEventListener('keydown', e => {
  if (e.key === 'Tab') {
    e.preventDefault();
    const start = editor.selectionStart;
    const end   = editor.selectionEnd;
    editor.value = editor.value.substring(0, start) + '  ' + editor.value.substring(end);
    editor.selectionStart = editor.selectionEnd = start + 2;
    editor.dispatchEvent(new Event('input'));
  }
});

// ── Keyboard shortcuts ────────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  const mod = e.ctrlKey || e.metaKey;
  if (!mod) return;
  switch (e.key.toLowerCase()) {
    case 's': e.preventDefault(); saveMarkdown();      break;
    case 'e': e.preventDefault(); exportHtml();        break;
    case 'p': e.preventDefault(); openPrintPreview();  break;
    case '1': e.preventDefault(); setMode('editor');   break;
    case '2': e.preventDefault(); setMode('preview');  break;
    case '3': e.preventDefault(); setMode('split');    break;
    case '/': e.preventDefault(); setMode('help');     break;
  }
});

// ── Persistence ───────────────────────────────────────────────────────────
function loadSaved() {
  const saved = localStorage.getItem('md-studio-content');
  if (saved) {
    editor.value = saved;
    updateWordCount();
  } else {
    editor.value = `# Welcome to Markdown Studio

Start writing your document here. This editor supports **full** [CommonMark](https://commonmark.org) markdown.

## Features

- Live **preview** and **split** view
- Export to **.md** or **.html**
- **Print** preview with A4 layout
- Markdown **reference** panel

> Use the sidebar on the left to switch modes, save, or export your work.

\`\`\`
Ctrl/Cmd + S  → Save as .md
Ctrl/Cmd + E  → Export as HTML
Ctrl/Cmd + P  → Print preview
Ctrl/Cmd + 1  → Editor
Ctrl/Cmd + 2  → Preview
Ctrl/Cmd + 3  → Split view
Ctrl/Cmd + /  → Help
\`\`\`
`;
    updateWordCount();
  }
}

// ── Init ──────────────────────────────────────────────────────────────────
buildHelp();
loadSaved();
setMode('editor');
